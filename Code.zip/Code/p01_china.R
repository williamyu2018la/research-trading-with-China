######################################################################################################
# P01_Panel regressions on China shock
# By William Yu, UCLA Anderson Forecast
# 3/4/2019, uodated 3/9/2019
##################################################################################################### 
setwd("C:/Users/wiyu/documents/Zip03/Research/F10 China Imports and US Productivity/Data")

install.packages("foreign") 
install.packages("plm") 
library(readxl)
library(foreign) 
library(car)
library(gplots)
library(plm)
library(Formula)

china02 = data.frame(read_excel("Book6_LPGR.xlsx"))  

plotmeans(LPGR~sector, data=china02, p=0.9)
plotmeans(LPGR~year, data=china02, p=0.9)

##################################################
##
## Data #2: 2002-2016
##
##################################################

##
## (1) Table 2 Dependent Variable: MFPGR. Fixed Effect: Lag1
##
fe11=plm(MFPGR~log(lag1_M), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(MFPGR~log(lag1_M)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(MFPGR~log(lag1_M)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

fe15=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe15)

fe16=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE)+D_gression, 
         index=c("sector","year"), model="within", data=china02)
summary(fe16)

fe17=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE)+D_0916, 
         index=c("sector","year"), model="within", data=china02)
summary(fe17)

##
## (2) Dependent Variable: LPGR. Independent variables: current year  
##
fe11=plm(LPGR~MFPGR+log(M), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~MFPGR+log(M)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~MFPGR+log(M)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

fe15=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe15)

fe16=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE)+D_gression, 
         index=c("sector","year"), model="within", data=china02)
summary(fe16)

fe17=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE)+D_0916, 
         index=c("sector","year"), model="within", data=china02)
summary(fe17)






##
## (3) Dependent Variable: LPGR. Independent variables: lag year
##
fe11=plm(LPGR~MFPGR+log(lag1_M), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

fe15=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe15)

fe16=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE)+D_gression, 
         index=c("sector","year"), model="within", data=china02)
summary(fe16)

fe17=plm(LPGR~MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE)+D_0916, 
         index=c("sector","year"), model="within", data=china02)
summary(fe17)

##
## (3) Dependent Variable: MFPGR. 
##
fe11=plm(LPGR~MFPGR+log(M), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~MFPGR+log(M)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~MFPGR+log(M)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

fe15=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe15)

fe16=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE)+D_gression, 
         index=c("sector","year"), model="within", data=china02)
summary(fe16)

fe17=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)
         +log(M_NA)+log(X_NA)+log(NKE)+D_0916, 
         index=c("sector","year"), model="within", data=china02)
summary(fe17)








##
## (2) LPGR and MFPGR: Fixed Effect 
##

fe01=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)








##
## LPGR: Fixed Effect without year fixed effect
##

fe01=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)

# Fixed Effect: Lag1
fe11=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)




##
## LPGR and MFPGR: Fixed Effect 
##

fe01=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(LPGR~MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)

##
## LPGR and MFPGR: Fixed Effect 
##
fe01=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)

# Fixed Effect: Lag1
fe11=plm(LPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

# Fixed Effect: Lag1
fe11=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~lag1_LPGR+lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)


##
## MFPGR: Fixed Effect without year fixed effect
##

fe01=plm(MFPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(MFPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(M_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(MFPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(MFPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(M_NA)+log(X_NA)+log(NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)

##
## Fixed Effect: Lag1
##
fe11=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_M_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(MFPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_M_NA)+log(lag1_X_NA)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

##
## Fixed Effect: Lag1 of Dependent Variables
##
fe11=plm(MFPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(MFPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(MFPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(MFPGR~lag1_MFPGR+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)




############################################################################################
## Robustness Check
############################################################################################

# OLS
ols=lm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU), data=china02)
summary(ols)

# Fixed Effect
fe01=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe01)

fe02=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe02)

fe03=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe03)

fe04=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe04)

# Fixed Effect: Lag1
fe11=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe11)

fe12=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_M_EU)+log(lag1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe12)

fe13=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe13)

fe14=plm(LPGR~log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe14)

# Fixed Effect: Current and Lag1
fe21=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(TKE)+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+
           log(lag1_M_EU)+log(lag1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe21)

fe22=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(M_EU)+log(NKE)+log(lag1_M)+log(lag1_X)+log(lag1_M_oAsian)+
           log(lag1_M_EU)+log(lag1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe22)

fe23=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(TKE)+log(lag1_M)+
           log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe23)

fe24=plm(LPGR~log(M)+log(X)+log(M_oAsian)+log(X_oAsian)+log(M_EU)+log(X_EU)+log(NKE)+log(lag1_M)+
           log(lag1_X)+log(lag1_M_oAsian)+log(lag1_X_oAsian)+log(lag1_M_EU)+log(lag1_X_EU)
         +log(lag1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe24)

# Placebo Effect: Lead 1
fe31=plm(LPGR~log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_M_EU)+log(lead1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe31)

fe32=plm(LPGR~log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_M_EU)+log(lead1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe32)

fe33=plm(LPGR~log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_X_oAsian)+log(lead1_M_EU)+log(lead1_X_EU)
         +log(lead1_TKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe33)

fe34=plm(LPGR~log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_X_oAsian)+log(lead1_M_EU)+log(lead1_X_EU)
         +log(lead1_NKE)+factor(year), 
         index=c("sector","year"), model="within", data=china02)
summary(fe34)

# Placebo Effect: Lead 1
fe31=plm(LPGR~lead1_MFPGR+log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_M_EU)+log(lead1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe31)

fe32=plm(LPGR~lead1_MFPGR+log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_M_EU)+log(lead1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe32)

fe33=plm(LPGR~lead1_MFPGR+log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_X_oAsian)+log(lead1_M_EU)+log(lead1_X_EU)
         +log(lead1_TKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe33)

fe34=plm(LPGR~lead1_MFPGR+log(lead1_M)+log(lead1_X)+log(lead1_M_oAsian)+log(lead1_X_oAsian)+log(lead1_M_EU)+log(lead1_X_EU)
         +log(lead1_NKE), 
         index=c("sector","year"), model="within", data=china02)
summary(fe34)
