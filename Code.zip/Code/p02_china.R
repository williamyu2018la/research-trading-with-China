######################################################################################################
# P02_Panel regressions on China shock
# By William Yu, UCLA Anderson Forecast
# 3/4/2019, uodated 3/9/2019
##################################################################################################### 
setwd("C:/Users/wyu/documents/Zip03/Research/F10 China Imports and US Productivity/Data")

install.packages("foreign") 
install.packages("plm") 
library(readxl)
library(foreign) 
library(car)
library(gplots)
library(plm)
library(Formula)

china01 = data.frame(read_excel("Book5_FDI.xlsx"))  

plotmeans(LPGR~sector, data=china02, p=0.9)
plotmeans(LPGR~year, data=china02, p=0.9)

############
##
## Data #1: 1994-2016
##
############
# Fixed Effect
fe41=plm(LPGR ~ FDI_to_China +log(TKE) + Edu + Age + factor(year), 
         index=c("sector","year"), model="within", data=china01)
summary(fe41)

fe42=plm(LPGR ~ FDI_to_China +log(NKE) + Edu + Age + factor(year), 
         index=c("sector","year"), model="within", data=china01)
summary(fe42)

fe43=plm(LPGR ~ FDI_to_China +log(TKE) + MFPGR + Edu + Age + factor(year), 
         index=c("sector","year"), model="within", data=china01)
summary(fe43)

fe44=plm(LPGR ~ FDI_to_China +log(NKE) + MFPGR + Edu + Age + factor(year), 
         index=c("sector","year"), model="within", data=china01)
summary(fe44)
